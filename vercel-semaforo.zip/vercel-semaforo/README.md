# 🚀 Semáforo v4.0 - Dashboard

Dashboard de gestión de incidencias para administrador de fincas.

## 📋 Características
- ✅ Sincronización con Firebase Firestore (Incidencias, Borradores, Dudas)
- 📅 Integración Google Calendar
- 📧 Integración Gmail
- ✓ Integración Google Tasks
- 🔄 Auto-sincronización cada 30 segundos

## 🚀 Desplegar en Vercel

### Opción 1: Click Deploy (Recomendado)
1. Ve a https://vercel.com/new
2. Conecta tu GitHub
3. Selecciona este repositorio
4. Click "Deploy"
5. ¡Listo! Tu dashboard está en producción

### Opción 2: Vercel CLI
```bash
npm i -g vercel
cd /ruta/a/esta/carpeta
vercel
```

### Opción 3: Arrastrar y soltar
1. Ve a https://vercel.com/new/static
2. Arrastra la carpeta aquí
3. ¡Listo!

## ⚙️ Configuración
El dashboard está preconfigurado con:
- 🔑 Firebase API Key: AIzaSyDWGtp5r77zWwc6Hiq4JJR4XhPwkSkOchA
- 🔧 Google Apps Script URL: https://script.google.com/macros/s/AKfycbw8VfKRNcQA8mmMGVrBUqW_6OxEO7azCfXXN6GLBq8gPi4Oh4Qokw3_DwIXZW-LDEtk0w/exec

Sin necesidad de cambios adicionales.
